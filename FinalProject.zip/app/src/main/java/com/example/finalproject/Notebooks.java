package com.example.finalproject;

public class Notebooks {
    String notebook_name;
    int image_id;

    public Notebooks (int id, String name) {
        this.notebook_name = name;
        this.image_id = id;
    }

    public String getNotebook_name() {
        return notebook_name;
    }

    public int getImage_id() {
        return image_id;
    }
}
