package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends Activity {
    private Intent intent;
    private int number;
    private String text;
    private ImageView imageView;
    private ImageView imageView2;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        intent = getIntent();
        number = intent.getIntExtra("number", -1);
        text = intent.getStringExtra("text");

        imageView = findViewById(R.id.imageView3);
        imageView2 = findViewById(R.id.imageView4);
        textView = findViewById(R.id.textView2);

        switch (number)
        {
            case 0:
                imageView.setImageResource(R.drawable.zen_2);
                imageView2.setImageResource(R.drawable.zen_3);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : ASUS\n");
                textView.append("CPU : i7-1165G7, RAM : 16GB\n");
                textView.append("가격 : 1149000원\n");
                textView.append("https://www.asus.com/kr/");
                break;

            case 1:
                imageView.setImageResource(R.drawable.htfx_2);
                imageView2.setImageResource(R.drawable.htfx_3);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : 한성컴퓨터\n");
                textView.append("CPU : i5-11300H, RAM : 16GB\n");
                textView.append("가격 : 1049000원\n");
                textView.append("https://www.monsterlabs.co.kr/");
                break;

            case 2:
                imageView.setImageResource(R.drawable.vivo_1);
                imageView2.setImageResource(R.drawable.vivo_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : ASUS\n");
                textView.append("CPU : i5-11300H, RAM : 16GB\n");
                textView.append("가격 : 1190000원\n");
                textView.append("https://www.asus.com/kr/");
                break;

            case 3:
                imageView.setImageResource(R.drawable.legion5_1);
                imageView2.setImageResource(R.drawable.legion5_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : 레노버\n");
                textView.append("CPU : 라이젠7-4세대, RAM : 16GB\n");
                textView.append("가격 : 1849000원\n");
                textView.append("https://www.lenovo.com/kr/ko?Redirect=False");
                break;

            case 4:
                imageView.setImageResource(R.drawable.samnt350_1);
                imageView2.setImageResource(R.drawable.samnt350_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : 삼성전자\n");
                textView.append("CPU : i5-10210U, RAM : 8GB\n");
                textView.append("가격 : 689000원\n");
                textView.append("https://www.samsung.com");
                break;

            case 5:
                imageView.setImageResource(R.drawable.swift_1);
                imageView2.setImageResource(R.drawable.swift_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : Acer\n");
                textView.append("CPU : 라이젠5-4세대, RAM : 16GB\n");
                textView.append("가격 : 1151000원\n");
                textView.append("https://www.acer.com/ac/ko/KR/content/home");
                break;

            case 6:
                imageView.setImageResource(R.drawable.lg2021_1);
                imageView2.setImageResource(R.drawable.lg2021_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : : LG전자\n");
                textView.append("CPU : i5-1135G7, RAM : 8GB\n");
                textView.append("가격 : 850000원\n");
                textView.append("https://www.lge.co.kr/");
                break;

            case 7:
                imageView.setImageResource(R.drawable.ideapad_1);
                imageView2.setImageResource(R.drawable.ideapad_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : 레노버\n");
                textView.append("CPU : i5-1135G7, RAM : 16GB\n");
                textView.append("가격 : 849000원\n");
                textView.append("https://www.lenovo.com/kr/ko?Redirect=False");
                break;

            case 8:
                imageView.setImageResource(R.drawable.msi_1);
                imageView2.setImageResource(R.drawable.msi_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : MSI\n");
                textView.append("CPU : i7-11800H, RAM : 16GB\n");
                textView.append("가격 : 2517000원\n");
                textView.append("https://kr.msi.com/");
                break;

            case 9:
                imageView.setImageResource(R.drawable.lg2021_1);
                imageView2.setImageResource(R.drawable.lg2021_2);
                textView.setText(text);
                textView.append("\n");
                textView.append("제조사 : MSI\n");
                textView.append("CPU : i7-11370H, RAM : 16GB\n");
                textView.append("가격 : 1368000원\n");
                textView.append("https://kr.msi.com/");
                break;

            case 10:
                sendEmail();
                break;

            case 11:
                sendCall();
                break;

            case 12:
                showMap2();
                break;

        }
    }

    protected void sendEmail() {
        String[] TO = {"sangwoo9808@naver.com"};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);

        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);

        try {
            startActivity(Intent.createChooser(emailIntent, "이메일 보내기..."));
            finish();
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(MainActivity2.this, "이메일 클라이언트가 없음.", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    protected void sendCall() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:01034531722"));
        startActivity(intent);
        finish();
    }

    protected void showMap() {
        Uri IntentUri = Uri.parse("geo:37.55827, 126.998425");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, IntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        }
    }

    protected void showMap2() {
        Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
        startActivity(intent);
        finish();
    }

}