package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private RecyclerView myRecyclerView;
    private RecyclerView.LayoutManager myLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        myRecyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        myRecyclerView.setHasFixedSize(true);
        myLayoutManager = new LinearLayoutManager(this);
        myRecyclerView.setLayoutManager(myLayoutManager);

        ArrayList<Notebooks> bookinfo = new ArrayList<>();
        bookinfo.add(new Notebooks(R.drawable.zen, "ASUS 젠북"));
        bookinfo.add(new Notebooks(R.drawable.htfx_1, "한성컴퓨터 TFX7130H"));
        bookinfo.add(new Notebooks(R.drawable.vivo_1, "ASUS 비보북 프로 15"));
        bookinfo.add(new Notebooks(R.drawable.legion5_1, "레노버 LEGION5 Pro"));
        bookinfo.add(new Notebooks(R.drawable.samnt350_1, "삼성전자 NT350XCR"));
        bookinfo.add(new Notebooks(R.drawable.swift_1, "에이서 스위프트X SFX14"));
        bookinfo.add(new Notebooks(R.drawable.lg2021_1, "LG전자 2021 울트라PC 15"));
        bookinfo.add(new Notebooks(R.drawable.ideapad_1, "레노버 아이디어패드 Slim-5"));
        bookinfo.add(new Notebooks(R.drawable.msi_1, "MSI 크리에이터 Z16 A11UE"));
        bookinfo.add(new Notebooks(R.drawable.msim_1, "MSI 모던시리즈 모던14"));
        bookinfo.add(new Notebooks(R.drawable.mail, "ICE.COM 고객센터 EMAIL"));
        bookinfo.add(new Notebooks(R.drawable.call, "ICE.COM 고객센터 전화"));
        bookinfo.add(new Notebooks(R.drawable.map, "ICE.COM 고객센터 위치"));

        MyAdapter myAdapter = new MyAdapter(bookinfo);

        myRecyclerView.setAdapter(myAdapter);
    }
}