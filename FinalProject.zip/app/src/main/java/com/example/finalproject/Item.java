package com.example.finalproject;

public class Item {
    private int item_image;
    private String item_text;

    public Item(int item_image, String item_text) {
        this.item_image = item_image;
        this.item_text = item_text;
    }

    public String getItem_title() {
        return item_text;
    }
    public int getItem_image() {
        return item_image;
    }

    public void setItem_text(String item_text) {
        this.item_text = item_text;
    }
    public void setItem_image(int item_image) {
        this.item_image = item_image;
    }
}